/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

/**
 * The {@code Profile} classes are used to manage the user's profile
 * The {@code view.Profile} class provides the interface to the user
 *
 * @author Saniya
 */
import controller.ProfileController;
import java.util.Scanner;

/**
 * The {@code ProfileView} class provides the user interface for profile management.
 */
public class ProfileView {
    private ProfileController controller;
    private Scanner scanner;

    public ProfileView() {
        this.controller = new ProfileController();
        this.scanner = new Scanner(System.in);
    }

    public void deleteAccount() {
        System.out.print("Enter your email: ");
        String email = scanner.nextLine();
        boolean success = controller.deleteAccount(email);
        if (success) {
            System.out.println("Account deleted successfully.");
        } else {
            System.out.println("Failed to delete account.");
        }
    }

    public void updateUsername() {
        System.out.print("Enter your email: ");
        String email = scanner.nextLine();
        System.out.print("Enter your new username: ");
        String newUsername = scanner.nextLine();
        controller.updateUsername(email, newUsername);
        System.out.println("Username updated successfully.");
    }

    public void updatePassword() {
        System.out.print("Enter your email: ");
        String email = scanner.nextLine();
        System.out.print("Enter your new password: ");
        String newPassword = scanner.nextLine();
        controller.updatePassword(email, newPassword);
        System.out.println("Password updated successfully.");
    }

    public void showMenu() {
        while (true) {
            System.out.println("\nProfile Management:");
            System.out.println("1. Delete Account");
            System.out.println("2. Update Username");
            System.out.println("3. Update Password");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    deleteAccount();
                    break;
                case 2:
                    updateUsername();
                    break;
                case 3:
                    updatePassword();
                    break;
                case 4:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
