/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import java.util.ArrayList;

/**
 * The {@code Dashboard} classes provide the functionality to view the dashboard of events.
 * The {@code view.Dashboard} provides the user interface.
 *
 * @author sammy
 */
public class Dashboard {

    /**
     * Displays all the events sorted by date.
     */
    public void displayEvents() {}
    
    /**
     * Displays a single event in a pop-up
     */
    public void displayEvent() {}
    
    /**
     * Creates the graph by accepting required parameter inputs in a form
     *
     * @param args The required and optional arguments for creating the graph.
     */
    public void graphForm(ArrayList<String> args) {}
}
