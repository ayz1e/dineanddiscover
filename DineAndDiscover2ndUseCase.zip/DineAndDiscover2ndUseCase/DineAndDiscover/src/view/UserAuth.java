package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * The {@code UserAuth} classes provide all the functionality to Login and Sign Up
 * The {@code view.UserAuth} class provides the interface for the user.
 */
public class UserAuth {
    private JFrame frame;
    private JPanel cards;
    private CardLayout cardLayout;
    private controller.UserAuth controller;

    public UserAuth() {
        // Initialize the frame, card layout, and controller
        frame = new JFrame("Dine&Discover - User Authentication");
        cardLayout = new CardLayout();
        cards = new JPanel(cardLayout);
        controller = new controller.UserAuth(); // Initialize the controller
    }

    /**
     * Creates the form into which email and password are entered.
     *
     * <p>Contains one submit button that is clickable only when the entered data is valid</p>
     */
    public void displayForm() {
        // Set up the main frame
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 500); // Reduced size

        // Create and add the login and signup forms to the cards panel
        cards.add(createLogin(), "Login");
        cards.add(createSignup(), "Signup");

        // Add the cards panel to the frame
        frame.add(cards);

        // Display the login form initially
        cardLayout.show(cards, "Login");

        // Set the frame to be visible
        frame.setVisible(true);

        // Set window listener to close the model connection
        frame.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                controller.closeModel();
            }
        });
    }
    

    private JPanel createLogin() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(120, 20, 120, 20)); // Increase border for spacing

        JPanel formPanel = new JPanel(new GridLayout(3, 1, 10, 10)); // Increase rows for components
        formPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Increase inner padding

        JLabel titleLabel = new JLabel("Sign In", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24)); // Larger font size
        formPanel.add(titleLabel);

        JPanel inputPanel = new JPanel(new GridLayout(2, 2, 5, 5)); // Increase rows for components
        JLabel emailLabel = new JLabel("Email:");
        JTextField emailText = new JTextField(20);
        JLabel passLabel = new JLabel("Password:");
        JPasswordField passText = new JPasswordField(20);

        inputPanel.add(emailLabel);
        inputPanel.add(emailText);
        inputPanel.add(passLabel);
        inputPanel.add(passText);

        formPanel.add(inputPanel);

        JPanel loginPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton loginButton = new JButton("Login");
        loginButton.setFont(new Font("Arial", Font.PLAIN, 12)); // Larger font size
      
        loginPanel.add(loginButton);
        formPanel.add(loginPanel);

        // Add "Don't have an account?" label and "Sign Up" button
        JPanel signupPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JLabel noAccountLabel = new JLabel("Don't have an account?");
        noAccountLabel.setFont(new Font("Arial", Font.PLAIN, 12)); // Larger font size
        JButton signUpButton = new JButton("Sign Up");
        signUpButton.setFont(new Font("Arial", Font.PLAIN, 12)); // Larger font size

        signupPanel.add(noAccountLabel);
        signupPanel.add(signUpButton);

        panel.add(formPanel, BorderLayout.CENTER);
        panel.add(signupPanel, BorderLayout.SOUTH);

        // Add action listener for the login button
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String email = emailText.getText();
                String password = new String(passText.getPassword());
                if (!controller.checkEmailValidity(email)) {
                    displayErrors("Incorrect login credentials");
                } else if (!controller.checkPasswordValidity(password)) {
                    displayErrors("Incorrect login credentials");
                } else if (controller.checkData(email, password)) {
                    JOptionPane.showMessageDialog(panel, "Login successful for email: " + email);
                } else {
                    displayErrors("Incorrect login credentials");
                }
            }
        });

        // Add action listener for the sign up button
        signUpButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(cards, "Signup");
            }
        });

        return panel;
    }

    private JPanel createSignup() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20)); // Increase border for spacing

        JPanel formPanel = new JPanel(new GridLayout(4, 1, 0, 10)); // Increase rows for components
        formPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 1, 10)); // Increase inner padding

        JLabel titleLabel = new JLabel("Sign Up", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24)); // Larger font size
        formPanel.add(titleLabel);

        JPanel inputPanel = new JPanel(new GridLayout(3, 2, 5, 5)); // Increase rows for components
        JLabel emailLabel = new JLabel("Email:");
        JTextField emailText = new JTextField(20);
        JLabel passLabel = new JLabel("Password:");
        JPasswordField passText = new JPasswordField(20);
        JLabel confirmPassLabel = new JLabel("Confirm Password:");
        JPasswordField confirmPassText = new JPasswordField(20);

        inputPanel.add(emailLabel);
        inputPanel.add(emailText);
        inputPanel.add(passLabel);
        inputPanel.add(passText);
        inputPanel.add(confirmPassLabel);
        inputPanel.add(confirmPassText);

        formPanel.add(inputPanel);

        JPanel registerPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton registerButton = new JButton("Register");
        registerButton.setFont(new Font("Arial", Font.PLAIN, 12)); // Larger font size
        
        registerPanel.add(registerButton);
        formPanel.add(registerPanel);

        // Add "Already have an account?" label and "Login" button
        JPanel loginPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JLabel haveAccountLabel = new JLabel("Already have an account?");
        haveAccountLabel.setFont(new Font("Arial", Font.PLAIN, 12)); // Larger font size
        JButton loginButton = new JButton("Login");
        loginButton.setFont(new Font("Arial", Font.PLAIN, 12)); // Larger font size

        loginPanel.add(haveAccountLabel);
        loginPanel.add(loginButton);

        panel.add(formPanel, BorderLayout.CENTER);
        panel.add(loginPanel, BorderLayout.SOUTH);

        // Add action listener for the register button
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String email = emailText.getText();
                String password = new String(passText.getPassword());
                String confirmPassword = new String(confirmPassText.getPassword());

                if (!password.equals(confirmPassword)) {
                    displayErrors("Passwords do not match.");
                    return;
                }

                if (!controller.checkEmailValidity(email)) {
                    displayErrors("Invalid email.");
                } else if (!controller.checkPasswordValidity(password)) {
                    displayErrors("Password does not meet complexity requirements. (8 or more characters with at least 1 uppercase, lowercase and number.");
                } else if (!controller.checkUnique(email)) {
                    displayErrors("Email already exists.");
                } else {
                    controller.registerUser(email, password);
                    JOptionPane.showMessageDialog(panel, "Registration successful for email: " + email);
                    cardLayout.show(cards, "Login");
                }
            }
        });

        // Add action listener for the login button in signup form
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(cards, "Login");
            }
        });

        return panel;
    }

    /**
     * Prints any errors returned by the controller.
     * @param e The error string to print.
     */
    public void displayErrors(String e) {
        JOptionPane.showMessageDialog(frame, e, "Error", JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {
        // Create an instance of UserAuth and display the form
        UserAuth userAuth = new UserAuth();
        userAuth.displayForm();
    }
}
