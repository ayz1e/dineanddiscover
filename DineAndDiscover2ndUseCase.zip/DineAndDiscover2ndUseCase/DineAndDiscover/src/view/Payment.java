/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

/**
 * The {@code Payment} classes provide the payment services through a third-party.
 * The {@code view.Payment} class provides the interface to the user.
 *
 * @author sammy
 */
public class Payment {
    
    /**
     * Displays the form for taking in any payment and sends data to controller to process.
     */
    public void paymentForm() {}
}
