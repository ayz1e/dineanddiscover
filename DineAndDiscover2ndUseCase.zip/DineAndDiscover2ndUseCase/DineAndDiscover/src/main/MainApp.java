/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

import view.ProfileView;

/**
 *
 * @author sammy
 */
public class MainApp {
    private static view.UserAuth userAuthView;
    
    public static void main(String[] args) {
        userAuthView = new view.UserAuth();
        userAuthView.displayForm();
        ProfileView view = new ProfileView();
        view.showMenu();
    }
}
