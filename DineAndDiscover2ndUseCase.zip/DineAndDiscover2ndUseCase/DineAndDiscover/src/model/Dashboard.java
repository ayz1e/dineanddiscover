/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.ArrayList;

/**
 * The {@code Dashboard} classes provide the functionality to view the dashboard of events.
 * The {@code model.Dashboard} class provides the business logic and connection to the database.
 *
 * @author sammy
 */
public class Dashboard {

    /** 
     * Returns the specified events by IDs. 
     *
     * @param ids The IDs of the events requested by controller.
     */
    public void returnEvents(ArrayList<String> ids) {}

    /**
     * Returns requested data of events. 
     *
     * @param request The request sent by controller.
     */
    public void returnData(ArrayList<String> request) {}
}
