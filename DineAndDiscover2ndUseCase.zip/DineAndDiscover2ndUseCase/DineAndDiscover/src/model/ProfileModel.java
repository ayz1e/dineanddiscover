


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.HashMap;
import java.util.Map;

/**
 * The {@code Profile} classes are used to manage the user's profile
 * The {@code model.Profile} class provides the business logic and connects to the database
 *
 * @author Isabelle & Saniya
**/

public class ProfileModel {
    
    // Simulated database
    private static Map<String, User> database = new HashMap<>();

    /**
     * Delete the account corresponding to the given email.
     *
     * @param email The user's registered email
     * @return Whether the deletion was successful
     */
    public boolean deleteAccount(String email) {
        if (database.containsKey(email)) {
            database.remove(email);
            System.out.println("Account deleted for email: " + email);
            return true;
        } else {
            System.out.println("No account found for email: " + email);
            return false;
        }
    }

    /**
     * Updates the username corresponding to the given email in the database.
     *
     * @param email The user's registered email
     * @param newUsername The new username
     */
    public void updateUsername(String email, String newUsername) {
        User user = database.get(email);
        if (user != null) {
            user.setUsername(newUsername);
            System.out.println("Username updated for email: " + email + " to " + newUsername);
        } else {
            System.out.println("No account found for email: " + email);
        }
    }

    /**
     * Updates the password corresponding to the given email in the database.
     *
     * @param email The user's registered email
     * @param newPassword The new password
     */
    public void updatePassword(String email, String newPassword) {
        User user = database.get(email);
        if (user != null) {
            user.setPassword(newPassword);
            System.out.println("Password updated for email: " + email);
        } else {
            System.out.println("No account found for email: " + email);
        }
    }

    /**
     * Checks if the given username is unique.
     *
     * @param username The entered username
     * @return Whether the username is unique or not
     */
    public boolean isUsernameUnique(String username) {
        for (User user : database.values()) {
            if (user.getUsername().equals(username)) {
                System.out.println("Username " + username + " is not unique.");
                return false;
            }
        }
        System.out.println("Username " + username + " is unique.");
        return true;
    }

    // Inner class to represent a user
    private static class User {
        private String email;
        private String username;
        private String password;

        public User(String email, String username, String password) {
            this.email = email;
            this.username = username;
            this.password = password;
        }

        public String getEmail() {
            return email;
        }

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }
    }
}