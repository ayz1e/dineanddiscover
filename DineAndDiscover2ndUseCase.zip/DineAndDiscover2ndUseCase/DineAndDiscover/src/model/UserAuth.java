/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.sql.*;

/**
 * The {@code UserAuth} classes provide all the functionality to Login and Sign Up
 * The {@code model.UserAuth} class provides the business logic and connection with the database.
 * @author sammy
 */
public class UserAuth {
    private Connection conn;
    
    public UserAuth() {
        
        // load SQLite JDBC driver
        try {
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        
        // Creates the users.db file
        String dbUrl = "jdbc:sqlite:users.db";
        try {
            conn = DriverManager.getConnection(dbUrl);
            initializeDatabase();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    private void initializeDatabase() {
        String sql = "CREATE TABLE IF NOT EXISTS users (email TEXT PRIMARY KEY, password TEXT)";
        try (Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    /**
     * Checks whether the given email matches an entry in the database
     *
     * @param email The given email
     * @return Whether this exactly matches an entry in the database
     */
    public boolean checkData(String email) {
        String sql = "SELECT 1 FROM users WHERE email = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, email);
            ResultSet rs = pstmt.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Checks whether the given email and password match an entry in the database
     *
     * @param email The given email
     * @param password The given password
     * @return Whether these match exactly an entry in the database
     */
    public boolean checkData(String email, String password) {
        String sql = "SELECT 1 FROM users WHERE email = ? AND password = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, email);
            pstmt.setString(2, password);
            ResultSet rs = pstmt.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    public void updateData(String email, String password) {
        String sql = "INSERT INTO users (email, password) VALUES (?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, email);
            pstmt.setString(2, password);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public void close() {
        try {
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    } 
}
