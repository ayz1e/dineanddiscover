/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.ArrayList;

/**
 * The {@code Payment} classes provide the payment services through a third-party.
 * The {@code model.Payment} class provides the business logic and connection to third party payment provider.
 *
 * @author sammy
 */
public class Payment {

    /**
     * Makes the payment through the third-party service.
     *
     * @param info The information required by third party payment service to make payment.
     * @return Whether the payment was successful or not.
     */
    public boolean makePayment(ArrayList<String> info) {return true;}
}
