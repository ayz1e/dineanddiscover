package controller;

import java.util.Scanner;
import model.ProfileModel;

/**
 * The {@code ProfileController} class provides the controller logic and functionality
 * to manage the user's profile.
 *
 * @author Isabelle
 */
public class ProfileController extends SuperController {

    private ProfileModel profile;

    public ProfileController() {
        this.profile = new ProfileModel();
    }

    /**
     * Confirms with the user for account deletion and sends to model to delete.
     *
     * @param email The user's registered email.
     * @return whether the delete was successful or not
     */
    public boolean confirmDelete(String email) {
        // Validate the email format
        if (email == null || email.isEmpty()) {
            return false; // Email is invalid
        }

        // Confirm with the user for account deletion
        boolean userConfirmed = getUserConfirmation(email);
        if (!userConfirmed) {
            return false; // User did not confirm deletion
        }

        // Call the model to delete the account
        boolean deleteSuccessful = profile.deleteAccount(email);
        return deleteSuccessful; // Return the result of the deletion process
    }

    /**
     * Checks if the given username is a valid username for login.
     *
     * @param username The entered username
     * @return Whether the username is a valid one or not
     */
    public boolean checkValidity(String username) {
        // Validate the username format (e.g., non-empty, specific character rules)
        return username != null && !username.isEmpty() && username.matches("^[a-zA-Z0-9._-]{3,}$");
    }

    /**
     * Checks if the given username and password are both valid for sign up.
     *
     * @param username The entered username
     * @param password The entered password
     * @return Whether the entered username and password are valid or not
     */
    public boolean checkValidity(String username, String password) {
        // Validate username and password (e.g., non-empty, specific rules)
        boolean validUsername = checkValidity(username);
        boolean validPassword = password != null && !password.isEmpty() && password.length() >= 6;
        return validUsername && validPassword;
    }

    /**
     * Sends the given username to the model to check if it is unique.
     *
     * @param username The entered username
     * @return Whether it is unique or not
     */
    public boolean checkUnique(String username) {
        // Call the model to check the uniqueness of the username
        return profile.isUsernameUnique(username);
    }

    /**
     * Allows user to change username.
     *
     * @param email The user's registered email
     * @param newUsername The new username
     */
    public void updateUsername(String email, String newUsername) {
        // Validate the new username
        if (checkValidity(newUsername) && checkUnique(newUsername)) {
            // Call the model to change the username
            profile.updateUsername(email, newUsername);
        }
    }

    /**
     * Allows user to change password.
     *
     * @param email The user's registered email
     * @param newPassword The new password
     */
    public void updatePassword(String email, String newPassword) {
        // Validate the new password
        if (newPassword != null && !newPassword.isEmpty() && newPassword.length() >= 6) {
            // Call the model to change the password
            profile.updatePassword(email, newPassword);
        }
    }

    /**
     * Delete the account corresponding to the given email.
     *
     * @param email The user's registered email
     * @return Whether the deletion was successful
     */
    public boolean deleteAccount(String email) {
        // Validate the email format
        if (email == null || email.isEmpty()) {
            return false; // Email is invalid
        }

        // Call the model to delete the account
        return profile.deleteAccount(email);
    }

    // Helper methods (simulated for this example)

    private boolean getUserConfirmation(String email) {
        // Simulate user confirmation (this would be a real confirmation dialog in a real application)
        System.out.println("Are you sure you want to delete the account associated with " + email + "? (yes/no)");
        Scanner scanner = new Scanner(System.in);
        String response = scanner.nextLine();
        return response.equalsIgnoreCase("yes");
    }

    private boolean isUsernameUnique(String username) {
        // Call the model to check the uniqueness of the username
        return profile.isUsernameUnique(username);
    }
}