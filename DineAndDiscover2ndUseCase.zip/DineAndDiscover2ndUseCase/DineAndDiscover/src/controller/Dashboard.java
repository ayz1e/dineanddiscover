/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.util.ArrayList;

/**
 * The {@code Dashboard} classes provide the functionality to view the dashboard of events.
 * The {@code controller.Dashboard} class provides the controller logic and functionality.
 * 
 * @author sammy
 */
public class Dashboard extends SuperController {

    /**
     * Gets events with the given IDs from model to send to view.
     *
     * @param ids The IDs of the events to get from model
     */
    public void getEvents(ArrayList<String> ids) {}
    
        /**
     * Sends the request to the model and gets back the necessary data to create the graph.
     *
     * @param args The required and optional arguments for creating the graph.
     */
    public void getData(ArrayList<String> args) {}
}
