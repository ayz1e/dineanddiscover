/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

/**
 * The {@code SuperController} class is the base class that all controller classes inherit from.
 * 
 * <p>It provides the basic functionality required by all controllers including forwarding to a new page.</p>
 *
 * @author sammy
 */
public class SuperController {
    
    /** Forwards or redirects to the given page.
     *
     * @param pageName The name of the page to redirect to.
     */
    public void forwardToPage(String pageName) {}
}
