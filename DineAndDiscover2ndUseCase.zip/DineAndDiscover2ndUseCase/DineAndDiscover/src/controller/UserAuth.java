/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.util.regex.Pattern;

/**
 * The {@code UserAuth} classes provide all the functionality to Login and Sign Up
 * The {@code controller.UserAuth} class provides the controller logic and functionality.
 * @author sammy
 */
public class UserAuth extends SuperController{
    private model.UserAuth model;
    private static final String EMAIL_REGEX = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,6}$";
    
    public UserAuth() {
        model = new model.UserAuth();
    }
    /**
     * Checks if the given email is a valid email for Login.
     * 
     * @param email The entered email
     * @return Whether the email is a valid one or not
     */
    public boolean checkEmailValidity(String email) {
        Pattern pattern = Pattern.compile(EMAIL_REGEX);
        return pattern.matcher(email).matches();
    }
    
    /**
     * Checks if the given password is valid for Sign Up.
     *
     * @param password The entered password
     * @return Whether the entered password is valid or not
     */
    public boolean checkPasswordValidity(String password) {
        boolean hasUpper = false, hasLower = false, hasNum = false, hasLen = (password.length() >= 8);
        
        for (int i = 0; i < password.length(); i++) {
            if (!hasUpper && Character.isUpperCase(password.charAt(i))) {
                hasUpper = true;
            }
            
            if (!hasLower && Character.isLowerCase(password.charAt(i))) {
                hasLower = true;
            }
            
            if (!hasNum && Character.isDigit(password.charAt(i))) {
                hasNum = true;
            }
        }
        
        return hasUpper && hasLower && hasNum && hasLen;
    }

    /**
     * Sends the given email to the model to check if it is unique 
     *
     * @param email The entered email
     * @return Whether it is unique or not
     */
    public boolean checkUnique(String email) {
        return !model.checkData(email);
    }
    
    /**
     * Sends the given email and password to the model to check if they are correct. 
     * 
     * @param email The entered email
     * @param password The entered password
     * @return Whether the given email and password match an entry in the system
     */
    public boolean checkData(String email, String password) {
        return (model.checkData(email, password));
    }
    
    public void registerUser(String email, String password) {
        model.updateData(email, password);
    }
    
    public void closeModel() {
        model.close();
    }
}
