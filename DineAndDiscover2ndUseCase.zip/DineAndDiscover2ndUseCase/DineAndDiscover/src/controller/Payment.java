/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.util.ArrayList;

/**
 * The {@code Payment} classes provide the payment services through a third-party.
 * The {@code controller.Payment} class provides the controller logic and functionality.
 *
 * @author sammy
 */
public class Payment extends SuperController{

    /**
     * Gets the info from view to process, and sends to model to make payment
     *
     * @param info The information required to process and send to model to make payment.
     */
    public void processPayment(ArrayList<String> info) {}
}
